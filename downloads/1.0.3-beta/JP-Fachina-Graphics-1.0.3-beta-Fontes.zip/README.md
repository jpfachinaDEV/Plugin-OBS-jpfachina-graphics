# JPFachina OBS Controller — 1.0.3 beta

Plugin C++17/Qt 6.11.1 para **OBS Studio 33.0.1 x64 no Windows**.
Refatoração no projeto existente: editor local por categoria, gerenciador de
eventos em Cenas e associações às cenas reais exclusivamente em Link OBS.

![Painel nativo no OBS](artifacts/obs-native-operator.png)

Preserva as duas abas, 36 espaços iniciais com miniaturas 16:9, marca original,
seleção verde e confirmação vermelha de conteúdo efetivamente no programa.
Take/Out continuam independentes por categoria.

- [Instalar e operar](LEIA-ME.md)
- [Criar, editar e compartilhar scoreboards](docs/SCOREBOARDS.md)
- [Correção de carregamento no OBS 33](docs/FIX-OBS33-0.4.1.md)
- [Diagnóstico, arquivos alterados, testes e limites](docs/REFACTOR-0.4.md)
- [Compilar e empacotar](docs/BUILD.md)
- [Histórico da interface anterior](docs/REFACTOR-0.3.md)

O editor mantém os movimentos em memória, sem comandos ao OBS. Salvar prepara
os próximos Takes; Salvar e aplicar no ar também atualiza a categoria publicada.
As setas grandes aceitam incrementos de 1, 10 e 50 pixels e o teclado.

Cenas cria, renomeia, duplica, exclui e seleciona projetos com bibliotecas e
posições independentes. Trocar de projeto preserva a saída anterior e seu tally.
Link OBS oferece integração nativa ou conexão WebSocket 5 autenticada, com
host/porta/senha, reconexão e associações por UUID. Um OBS remoto precisa deste
plugin instalado e acesso aos arquivos da biblioteca; veja o manual.

Pacotes em `dist/`. Desenvolvimento: `build/jp-graphics-dev.exe --native-ui`.
O executável também pode conectar ao OBS por WebSocket. O HTML anterior permanece
para compatibilidade com fontes e integrações ainda referenciadas.

Testes usam bibliotecas temporárias e OBS portátil isolado. Incluem gravação
local real; transmissão externa, quatro horas contínuas e segundo monitor físico
ainda exigem homologação. A instalação principal não é modificada pelos testes.

Código GPL-2.0-or-later. A marca tem direitos próprios. Licenças de terceiros
acompanham o código e os pacotes.
